package Aplicacion.IoT_AplicacionRedes;

import org.telegram.telegrambots.bots.TelegramLongPollingBot;
import org.telegram.telegrambots.meta.api.objects.Update;
import org.telegram.telegrambots.meta.exceptions.TelegramApiException;
import org.telegram.telegrambots.meta.api.methods.send.SendMessage;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class TelgramBot extends TelegramLongPollingBot {
    private final ExecutorService executorService = Executors.newCachedThreadPool();

    @Override
    public void onUpdateReceived(Update update) {
    }

    @Override
    public String getBotUsername() {
        return "nombrebot";
    }

    @Override
    public String getBotToken() {
        return "Token del bot";
    }

    public void sendMessageToTelegram(String messageText) {          
            try {
            	SendMessage message = new SendMessage();
                message.setChatId("tu chat id"); 
                message.setText(messageText);
                execute(message);
                System.out.println("Mensaje enviado a Telegram: " + messageText);
            } catch (TelegramApiException e) {
                e.printStackTrace();
            }
      
    }
}