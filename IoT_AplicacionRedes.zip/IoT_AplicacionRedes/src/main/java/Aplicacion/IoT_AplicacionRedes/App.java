package Aplicacion.IoT_AplicacionRedes;
import java.util.UUID;

import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttAsyncClient;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.telegram.telegrambots.meta.TelegramBotsApi;
import org.telegram.telegrambots.meta.exceptions.TelegramApiException;
import org.telegram.telegrambots.meta.generics.LongPollingBot;
import org.telegram.telegrambots.updatesreceivers.DefaultBotSession;
public class App 
{
    public static MqttAsyncClient Cliente;
    String temp;
	public static void main( String[] args ) throws MqttException, TelegramApiException
    {
		try {
    TelegramBotsApi botsApi = new TelegramBotsApi(DefaultBotSession.class);
    TelgramBot bot = new TelgramBot();
	 botsApi.registerBot(bot);
	 System.out.println("Bot de Telegram registrado");
	 
     Cliente = new MqttAsyncClient("tcp://ip del broker:1883", UUID.randomUUID().toString());
     MyCallback CallBack= new MyCallback(bot);
    Cliente.setCallback(CallBack);
    
    IMqttToken token = Cliente.connect();	
    token.waitForCompletion();
    
    Cliente.subscribe("temperatura", 0);
		} catch (MqttException e) {
			e.printStackTrace();
		}
    }
}
