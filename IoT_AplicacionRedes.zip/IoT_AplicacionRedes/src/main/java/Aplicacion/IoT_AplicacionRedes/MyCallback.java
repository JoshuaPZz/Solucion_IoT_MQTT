package Aplicacion.IoT_AplicacionRedes;

import java.util.UUID;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttAsyncClient;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.telegram.telegrambots.meta.TelegramBotsApi;
import org.telegram.telegrambots.meta.api.methods.send.SendMessage;
import org.telegram.telegrambots.updatesreceivers.DefaultBotSession;

public class MyCallback implements MqttCallback
{
String temp;
float tempval;
private MqttAsyncClient Cliente;
private TelgramBot tele;

public MyCallback(TelgramBot tele) {
    this.tele = tele;
}
	@Override
	public void connectionLost(Throwable cause) {
		System.out.println("Conexión perdida: " + cause.getMessage());
		
	}

	@Override
	public void messageArrived(String opic, MqttMessage message) throws Exception {
		temp = message.toString();
		tempval = Float.parseFloat(temp);
		try {
		if(tempval>30) {
		
			System.out.println("Se publico hay peligro " + tempval);
			 byte[] payload = "true".getBytes();
			MqttMessage mensajepel = new MqttMessage(payload);
			App.Cliente.publish("peligro", mensajepel);
		//bot
			if (tele != null) {
                System.out.println("Enviando mensaje de peligro a Telegram.");
                tele.sendMessageToTelegram("CUIDADO, HAY PELIGRO DE POSIBLE INCENDIO FORESTAL, LA TEMPERATURA ESTA EN🏃🏻🔥🚒🥸: " + tempval);
            } else {
                System.err.println("Bot de Telegram no inicializado");
            }
		}
		else if( tempval<30) {
		
			System.out.println("Se publico no hay peligro " + tempval);
			 byte[] payload = "false".getBytes();
			MqttMessage mensajepel = new MqttMessage(payload);
			App.Cliente.publish("peligro", mensajepel);
		//bot
			if (tele != null) {
                System.out.println("Enviando mensaje de peligro a Telegram.");
                tele.sendMessageToTelegram("ACTUALMENTE,NO HAY PELIGRO DE INCENDIO, TU TRANQUILO YO NERVIOSO👨🏻‍🦽🐇🤹🏻: " + tempval);
            } else {
                System.err.println("Bot de Telegram no inicializado");
            }
		} 
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void deliveryComplete(IMqttDeliveryToken token) {
		System.out.println("Se publico el mensaje" );
		
	}

}
